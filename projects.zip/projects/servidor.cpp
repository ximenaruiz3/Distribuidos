#include "servidor.h"
#include <dirent.h>

int cont;


Servidor::Servidor(){
	this->puerto=9000;
	this->descriptorSer = -1;
	this->estado = false;
	this->idBind = -1;
}


Servidor::Servidor(int puerto){
	this->puerto=puerto;
	this->descriptorSer = -1;
	this->estado = false;
	this->idBind = -1;
}

void Servidor::inicializarServidor(){
	
	descriptorSer= socket(AF_INET,SOCK_STREAM,0);
	servidorInfo.sin_family=AF_INET;
	servidorInfo.sin_addr.s_addr=htonl(INADDR_ANY);
	servidorInfo.sin_port=htons(puerto);
	idBind=bind(descriptorSer,(struct sockaddr *)&servidorInfo, sizeof(servidorInfo));
	
	listen(descriptorSer, maxClientes);
	
	if(descriptorSer==-1 && idBind==-1)
		cout<<"Error iniciando el servidor."<<endl;
	
}

void Servidor::cerrarServidor(){
	exit(EXIT_SUCCESS);
}


void * Servidor::atenderPetCli(void * cli){
	ClienteInfo * cliente= (ClienteInfo *) cli;
	while(true){
		//Solicitud de cliente: enviar archivo----0 , obtener lista -----1
		cout << "Esperando...:"<< endl;
		char peticionCli [128];
		read(cliente->getDescriptorCliente(),peticionCli,128);
		int option = atoi(peticionCli);
		cout << "1opcion: :"<<option<<endl;
		if(option == 0){
			char peticion1 [128];
			strcpy(peticion1,"0");//Peticion de archivos de la maquina;
			vector<int> contadorArchivosMaq;
			for(int i = 0; i < cliente->getMaquinas()->size();i++){
				char tamanioArchivo[128];
				write(cliente->getMaquinas()->at(i)->getDescriptorCliente(),peticion1,128);
				write(cliente->getMaquinas()->at(i)->getDescriptorCliente(),peticion1,128);
			}
			cout << "para que cleinte envie tama�o: :"<<peticion1<<endl;
			for(int i = 0; i < cliente->getMaquinas()->size();i++){
				char tamanioArchivoa[128];
				read(cliente->getMaquinas()->at(i)->getDescriptorCliente(),tamanioArchivoa,128);
				cout << "recibe tamanios: :"<<tamanioArchivoa<<endl;
				contadorArchivosMaq.push_back(atoi(tamanioArchivoa));
			}
			vector<int> posMenor;
			int posPrimerMenor = 0;
			int posSegundoMenor = 1;
			posMenor.push_back(posPrimerMenor);
			posMenor.push_back(posSegundoMenor);
			
			
			char peticion2 [128];
			strcpy(peticion2,"0"); //Peticion para enviar archivo
			write(cliente->getMaquinas()->at(posMenor.at(0))->getDescriptorCliente(),peticion2,128);
			write(cliente->getMaquinas()->at(posMenor.at(1))->getDescriptorCliente(),peticion2,128);
			cout << "peticion para enviar archivo: :"<<endl;
			char peticion3 [128];
			strcpy(peticion3,"1"); //Peticion para enviar archivo
			write(cliente->getMaquinas()->at(posMenor.at(0))->getDescriptorCliente(),peticion3,128);
			write(cliente->getMaquinas()->at(posMenor.at(1))->getDescriptorCliente(),peticion3,128);
			cout << "se envian datos del archivo :"<<endl;
			
			
			char recvBuff[256];
			//datos archivo
			char fname[256];
			read(cliente->getDescriptorCliente(), fname, 256);
			cout<<"nombre de archivo: "<<fname<<endl;
			write(cliente->getMaquinas()->at(posMenor.at(0))->getDescriptorCliente(),fname,256);
			write(cliente->getMaquinas()->at(posMenor.at(1))->getDescriptorCliente(),fname,256);
			//Determinando tamanio del archivo
			char sizeChar[256];
			read(cliente->getDescriptorCliente(), sizeChar, sizeof(sizeChar));
			cout<<"obteniendo tama�o "<<sizeChar<<endl;
			write(cliente->getMaquinas()->at(posMenor.at(0))->getDescriptorCliente(), sizeChar, sizeof(sizeChar));
			write(cliente->getMaquinas()->at(posMenor.at(1))->getDescriptorCliente(), sizeChar, sizeof(sizeChar));
			int size = atoi(sizeChar);
			int rcBytes = 0;
			cout<< "Inicio de la transferencia del archivo."<<endl;
			while (rcBytes < size){
				rcBytes += read(cliente->getDescriptorCliente(), recvBuff, 256);
				write(cliente->getMaquinas()->at(posMenor.at(0))->getDescriptorCliente(), recvBuff,256);
				write(cliente->getMaquinas()->at(posMenor.at(1))->getDescriptorCliente(), recvBuff,256);
				cout<<recvBuff<<endl;
			}
			cout << "Transferencia completa." << endl;
			
		}
		
		if(option == 1){
			char tamMaquinas[128];
			int sizeMaq = cliente->getMaquinas()->size();
			sprintf(tamMaquinas,"%d", sizeMaq);
			write(cliente->getDescriptorCliente(), tamMaquinas,128);
			char selecMaqChar[128];
			read(cliente->getDescriptorCliente(), selecMaqChar,128);
			int selecMaq = atoi(selecMaqChar);
			
			//Enviando peticion para recibir listado
			ClienteInfo* maquina = cliente->getMaquinas()->at(selecMaq);
			char peticionMaquina[128];
			sprintf(peticionMaquina, "%d", 1);
			write(maquina->getDescriptorCliente(),peticionMaquina , 128);
			
			
			
			//leyendo de maquina y enviando al cliente
			char sizeListChar[128];
			read(maquina->getDescriptorCliente(), sizeListChar,128);
			write(cliente->getDescriptorCliente(),sizeListChar , 128);
			int size = atoi(sizeListChar);
			for (int i = 0; i < size; ++i) {
				char contList[256];
				read(maquina->getDescriptorCliente(), contList,256);
				write(cliente->getDescriptorCliente(),contList , 256);
			}
		}
		if(option == 2){
			char peticionMaquina[128];
			sprintf(peticionMaquina, "%d", 2);
			for (int i = 0; i < cliente->getMaquinas()->size(); ++i) {
				write(cliente->getMaquinas()->at(i)->getDescriptorCliente(),peticionMaquina, 128);
			}
			char petEliminado[128];
			read(cliente->getDescriptorCliente(), petEliminado,128);
			cout<<"Archivo a eliminar: "<<petEliminado<<endl;
			for (int i = 0; i < cliente->getMaquinas()->size(); ++i) {
				cout<<petEliminado<<endl;
				write(cliente->getMaquinas()->at(i)->getDescriptorCliente(),petEliminado, 128);
			}
			char taman[128];
			vector<int> sizes;
			char selec[128];
			int may;
			int posi;
			int men;
			int posii;
			char fnname[256];
			for (int i = 0; i < cliente->getMaquinas()->size(); ++i) {
				read(cliente->getMaquinas()->at(i)->getDescriptorCliente(),taman,128);
				int temp = atoi( taman );
				sizes.push_back(temp);
				cout<<"tama�o de la maquiina :c "<<temp<<endl;
			}
			bool bal = true;
				while(bal){
				may = sizes.at(0);
				men = sizes.at(0);
				posi=0;
				posii=0;
				for (int i = 1; i < sizes.size(); ++i) {
					if(may >= sizes.at(i)){
						
					}else{
						may = sizes.at(i);
						posi = i;
					}
					if(men <= sizes.at(i) ){
						
					}else{
						men = sizes.at(i);
						posii = i;
					}
				}
			if((may-men)<2){
					string lol = "ya esta balanceado";
					const char *cx = lol.c_str();
					write(cliente->getDescriptorCliente(),cx , 256);
					bal = false;
					sprintf(fnname, "%d", 2);
					write(cliente->getMaquinas()->at(posi)->getDescriptorCliente(),fnname,256);
				}else{
				sprintf(selec, "%d", 3);
				write(cliente->getMaquinas()->at(posi)->getDescriptorCliente(),selec, 128);
				write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(),selec, 128);
				sprintf(selec, "%d", 0);
				write(cliente->getMaquinas()->at(posi)->getDescriptorCliente(),selec, 128);
				cout<<"el tam del que envia: "<<sizes.at(posi)<<endl;
				sizes[posi] = sizes.at(posi)-1;
				cout<<"el tam del que envia nuevo: "<<sizes.at(posi)<<endl;
				cout<< "envio la opcion de que envie un archivo"<<endl;
				sprintf(selec, "%d", 1);
				write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(),selec, 128);
				cout<<"el tam del que recibe: "<<sizes.at(posii)<<endl;
				sizes[posii] = sizes.at(posii)+1;
				cout<<"el tam del que recibe nuevo: "<<sizes.at(posii)<<endl;
				cout<< "envio la opcion de que reciba un archivo"<<endl;
					char recvBuuff[256];
					//datos archivo
					bool cd = true;
					
					
					read(cliente->getMaquinas()->at(posi)->getDescriptorCliente(), fnname, 256);
					write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(),fnname,256);
					while(cd){
						read(cliente->getMaquinas()->at(posii)->getDescriptorCliente(), fnname, 256);
						int cxz = atoi(fnname);
						if(cxz== 1){
							sprintf(fnname, "%d", 1);
							write(cliente->getMaquinas()->at(posi)->getDescriptorCliente(),fnname,256);
						}else{
							sprintf(fnname, "%d", 0);
							write(cliente->getMaquinas()->at(posi)->getDescriptorCliente(),fnname,256);
							break;
						}
						read(cliente->getMaquinas()->at(posi)->getDescriptorCliente(), fnname, 256);
						write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(),fnname,256);
					}
					//Determinando tamanio del archivo
					char sizzeChar[256];
					read(cliente->getMaquinas()->at(posi)->getDescriptorCliente(), sizzeChar, sizeof(sizzeChar));
					write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(), sizzeChar, sizeof(sizzeChar));
					int siize = atoi(sizzeChar);
					int rccBytes = 0;
					cout<< "Inicio de la transferencia del archivo."<<endl;
					while (rccBytes < siize){
						rccBytes += read(cliente->getMaquinas()->at(posi)->getDescriptorCliente(), recvBuuff, 256);
						write(cliente->getMaquinas()->at(posii)->getDescriptorCliente(), recvBuuff,256);
						
					}
					
				}
			}
		}
	}	
}

void Servidor::confirmacionCliente(ClienteInfo * cliente){
	char recvBuff[128];
	read(cliente->getDescriptorCliente(), recvBuff, 128);
	int almacenamiento = atoi(recvBuff);
	if(almacenamiento){
		maquinas.push_back(cliente);
		cout<<"Se ha conectado una maquina de almacenamiento."<<endl;
	}
	else{
		cout<<"Se ha conectado un cliente."<<endl;
		cliente->setMaquinas(&maquinas);
		pthread_t clientesHilos;
		pthread_create(&clientesHilos,NULL,&atenderPetCli,(void *) cliente);
	}
	
}


void Servidor::aceptarClientes(){
	
	int descriptorCliente;
	
	cont=0;
	
	while(cont<maxClientes){
		struct sockaddr_in clienteInfor;
		int tamano= sizeof(struct sockaddr_in);
		cout<<"Aceptando cliente..."<<endl;
		descriptorCliente=accept(this->descriptorSer,(struct sockaddr *)&clienteInfor,(socklen_t*) &tamano);
		
		//recibiendo clientes
		
		if(descriptorCliente!=-1){
			clientesDescriptor.push_back(new ClienteInfo(descriptorCliente,clienteInfor));
			confirmacionCliente(clientesDescriptor[cont]);
			cont++;
		}
	}
}

void * Servidor::comenzarServidor(void * servidor){
	Servidor * server=(Servidor *) servidor;
	server->aceptarClientes();
}

void Servidor::ejecutarServidor(){
	pthread_t hilo;
	pthread_create(&hilo,NULL,&comenzarServidor,(void *) this);
}



void Servidor::setDescriptorServidor(int descriptor){
	this->descriptorSer=descriptor;
}

void Servidor::setIdBin(int bind){
	this->idBind=bind;
}
void Servidor::setPuerto(int puerto){
	this->puerto=puerto;
}
void Servidor::setServidorInfo(struct sockaddr_in info){
	this->servidorInfo = info;
}



int Servidor::getDescriptorServidor(){
	return this->descriptorSer;
}
int Servidor::getIdBin(){
	return this->idBind;
}
int Servidor::getPuerto(){
	return this->puerto;
}
struct sockaddr_in Servidor::getServidorInfo(){
	return this->servidorInfo;
}

vector<ClienteInfo *> Servidor::getClientes(){
	return this->clientesDescriptor;
}

vector<ClienteInfo *> Servidor::getMaquinas(){
	return this->maquinas;
}
