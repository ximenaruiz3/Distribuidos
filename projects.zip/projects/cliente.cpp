#include "cliente.h"

Cliente::Cliente(){
	this->puertoServidor=1100;
	this->ipServidor="192.168.0.34";
	this->descriptorCliente = -1;
	this->esAlmacenamiento = false;
}

Cliente::Cliente(int puerto, string ip){
	this->puertoServidor=puerto;
	this->ipServidor=ip;
	this->descriptorCliente = -1;
	this->esAlmacenamiento = false;
}
int tam;
void * Cliente::escucharServidor(void * cli){
	Cliente* cliente=(Cliente *) cli;
	char mensajeDeServidor[60];
	
	while(1){
		recv(cliente->getDescriptor(),(void *)&mensajeDeServidor ,60,0);
		cout<<mensajeDeServidor<<endl;
	}
}

void Cliente::confirmacionAlmacenamiento(Cliente * cliente){
	
	char msg[128];
	if(cliente->getAlmacenamiento()){
		strcpy(msg,"1");
	}else strcpy(msg,"0");
	
	int i=send(cliente->getDescriptor(),(void *)msg,sizeof(msg),0);
	sleep(1);
	
	if(i==-1){
		cout<<"se desconecto del servidor"<<endl;
		close(cliente->getDescriptor());
		exit(EXIT_SUCCESS);
	}
	
}

void * Cliente::atenderPetAlma(void * cli){
	ClienteInfo * cliente=(ClienteInfo *) cli;
	while(true){
		
		char opcion [128];
		cout << "Esperando solicitud de servidor..." <<endl;
		read(cliente->getDescriptorCliente(), opcion, 128);
		int pet1 = atoi(opcion);
		cout <<"recibe --------"<<pet1<<endl;
		
		//Solicitud para recibir archivos
		if(pet1 == 0){
			char opcion2 [128];
			read(cliente->getDescriptorCliente(), opcion2, 128);
			cout <<"para saber si envia tamano o recibe--------"<<opcion2<<endl;
			int pet2 = atoi(opcion2);
			if(pet2==1){
				cout<<"va a enviar archivo: "<<pet2<<endl;
				FILE *fpg;
				char recvBuff[256];
				//Creando archivo
				char fname[256];
				read(cliente->getDescriptorCliente(), fname, 256);
				char path[256];
				strcpy(path, "archivosMA/");
				strcat(path,fname);
				fpg = fopen(path, "ab");
				cout<< "Archivo: "<< path <<endl;
				//Obteniendo el tamanio del archivo
				char sizeChar[256];
				read(cliente->getDescriptorCliente(), sizeChar, sizeof(sizeChar));
				int size = atoi(sizeChar);
				cout<< "Tamanio: " <<size<< endl;
				int rcBytes = 0;
				cout<< "Transfiriendo el archivo..." << endl;
				while (rcBytes < size){
					rcBytes = rcBytes + read(cliente->getDescriptorCliente(), recvBuff, 256);
					fwrite(recvBuff, 1,sizeof(recvBuff),fpg);
				}
				fclose(fpg);
				cout<< "Se ha terminado la transferencia."<<endl;
			}else{
				//Solicitud para saber numero de archivos
				
				int counter = 0;
				DIR *dir;
				struct dirent *ent;
				if ((dir = opendir ("archivosMA/")) != NULL) {
					/* print all the files and directories within directory */
					while ((ent = readdir (dir)) != NULL) {
						if(!(strcmp(ent->d_name,".")==0 || strcmp(ent->d_name,"..")==0))	
							counter++;
					}
					closedir (dir);
				} else {
					cout << "No se pudo abrir el directorio" << endl;
				}
				char counterChar[128];
				sprintf(counterChar,"%d",counter);
				tam = counter;
				write(cliente->getDescriptorCliente(),counterChar,128);
				cout<<"envia el tamanio: "<<counterChar<<endl;
			}
		}
		if(pet1 == 1){
			// Solicitud para listado de archivos
			int counter = 0;
			DIR *dir;
			struct dirent *ent;
			if ((dir = opendir ("archivosMA/")) != NULL) {
				/* print all the files and directories within directory */
				while ((ent = readdir (dir)) != NULL) {
					if(!(strcmp(ent->d_name,".")==0 || strcmp(ent->d_name,"..")==0))	
						counter++;
				}
				closedir (dir);
			} else {
				cout << "No se pudo abrir el directorio" << endl;
			}
			char counterChar[128];
			sprintf(counterChar,"%d",counter);
			write(cliente->getDescriptorCliente(),counterChar,128);
			
			if ((dir = opendir ("archivosMA/")) != NULL) {
				/* print all the files and directories within directory */
				while ((ent = readdir (dir)) != NULL) {
					if(!(strcmp(ent->d_name,".")==0 || strcmp(ent->d_name,"..")==0))	
						write(cliente->getDescriptorCliente(),ent->d_name,256);
				}
				closedir (dir);
			} else {
				cout << "No se pudo abrir el directorio" << endl;
			}
			
			
		}
		if(pet1 == 2){
			char petElim[128];
			read(cliente->getDescriptorCliente(), petElim,128);
			cout<<petElim<<endl;
			string ruta = "archivosMA/";
			ruta += petElim;
			const char *C = ruta.c_str();
			remove(C);
			cout<<"Se elimino: "<<petElim<<endl;
			int counte = 0;
			DIR *dirr;
			struct dirent *entt;
			if ((dirr = opendir ("archivosMA/")) != NULL) {
				/* print all the files and directories within directory */
				while ((entt = readdir (dirr)) != NULL) {
					if(!(strcmp(entt->d_name,".")==0 || strcmp(entt->d_name,"..")==0))	
						counte++;
				}
				closedir (dirr);
			} else {
				cout << "No se pudo abrir el directorio" << endl;
			}
			char counteChar[128];
			sprintf(counteChar,"%d",counte);
			write(cliente->getDescriptorCliente(),counteChar,128);
			
		}
		if(pet1 == 3){
			char op[128];
			DIR *direca;
			struct dirent *enta;
			read(cliente->getDescriptorCliente(), op,128);
			int pet1q = atoi(op);
			cout<< "llego la opcion de que envie o reciba un archivo"<<pet1q<<endl;
			if(pet1q==0){	
				
				if ((direca = opendir ("archivosMA/")) != NULL) {
					/* print all the files and directories within directory */
					while ((enta = readdir (direca)) != NULL) {
						if(!(strcmp(enta->d_name,".")==0 || strcmp(enta->d_name,"..")==0)){
							cout<<"el archivo a enviar "<<enta->d_name<<endl;
							write(cliente->getDescriptorCliente(),enta->d_name,256);
							char opa[256];
							read(cliente->getDescriptorCliente(), opa,256);
							int xv = atoi(opa);
							if(xv == 0){
								int siza = -1;
								char pathhh[256];
								strcpy(pathhh, "archivosMA/");
								strcat(pathhh,enta->d_name);
								FILE *fppa = fopen(pathhh,"rb");
								int fdda = fileno(fppa);
								fseek(fppa,0L, SEEK_END);
								siza = ftell(fppa);
								rewind(fppa);
								char sizeaCharr [256];
								sprintf(sizeaCharr,"%d",siza);
								write(cliente->getDescriptorCliente(),sizeaCharr, sizeof(sizeaCharr));
								if(fppa== NULL){
									printf("Error abriendo archivo");
								}else{
									
									while(1)
									{
										/* First read file in chunks of 256 bytes */
										unsigned char buffa[256]={0};
										int nreada = fread(buffa,1,256,fppa);
										//cout << buff<< endl;
										/* If read was success, send data. */
										if(nreada > 0)
										{
											//printf("Sending \n");
											write(cliente->getDescriptorCliente(), buffa, nreada);
										}
										if (nreada < 256)
										{
											if (feof(fppa))
											{
												printf("La transferencia ha terminado correctamente.\n");
												fclose(fppa);
												string rutax = "archivosMA/";
												rutax += enta->d_name;
												const char *Cb = rutax.c_str();
												remove(Cb);
												
											}
											if (ferror(fppa))
												printf("Error reading\n");
											break;
										}
									}
									
									
								}
								break;
							}else if(xv == 2){
								break;
							}
						}
						
					}		
					
				} else {
					cout << "No se pudo abrir el directorio" << endl;
				}
			}else if(pet1q==1){
				FILE *fps;
				char recvBufff[256];
				//Creando archivo
				bool cat =true;
				bool open = true;
				char fnamee[256];
				char* named;
				while(cat){
					read(cliente->getDescriptorCliente(), fnamee, 256);
					cout<<fnamee<<" el nombreeeeeeee"<<endl;
					DIR *dirra;
					struct dirent *enttx;
					if ((dirra = opendir ("archivosMA/")) != NULL) {
						/* print all the files and directories within directory */
						while ((enttx = readdir (dirra)) != NULL) {
							if(!(strcmp(enttx->d_name,".")==0 || strcmp(enttx->d_name,"..")==0)){	
								named = enttx->d_name;
								if(strcmp(named,fnamee)==0){
									char cop[256];
									sprintf(cop,"%d",1);
									write(cliente->getDescriptorCliente(),cop,256);
									cout<<"son iguales, se ignora "<<named<<"---"<<fnamee<<endl;
									open = false;
									break;
								}
								
								
							}
							
						}
						if(open){
							char copp[256];
							sprintf(copp,"%d",0);
							write(cliente->getDescriptorCliente(),copp,256);
							cout<<"no son iguales, se recibe "<<named<<"---"<<fnamee<<endl;
							cat = false;
						}
						closedir (dirra);
					} else {
						cout << "No se pudo abrir el directorio" << endl;
					}
				}
				char path1z[256];
				strcpy(path1z, "archivosMA/");
				strcat(path1z,fnamee);
				fps = fopen(path1z, "ab");
				cout<< "Archivo: "<< path1z <<endl;
				//Obteniendo el tamanio del archivo
				char sizeChaara[256];
				read(cliente->getDescriptorCliente(), sizeChaara, sizeof(sizeChaara));
				int sizeaz = atoi(sizeChaara);
				cout<< "Tamanio: " <<sizeaz<< endl;
				int rcBytesaa = 0;
				cout<< "Transfiriendo el archivo..." << endl;
				while (rcBytesaa < sizeaz){
					rcBytesaa = rcBytesaa + read(cliente->getDescriptorCliente(), recvBufff, 256);
					fwrite(recvBufff, 1,sizeof(recvBufff),fps);
				}
				fclose(fps);
				cout<< "Se ha terminado la transferencia."<<endl;
			}
		}
	}
}



void * Cliente::menuCliente(void * cli){
	Cliente* cliente=(Cliente *) cli;
	
	while(true){
		int option;
		cout<< "Seleccione: 0 para enviar archivo; 1 para ver listado de archivos de una maquina; 2 para borrar archivo "<<endl;
		cin >> option;
		if(option == 0){
			
			
			//Solicitud para enviar archivo ---- 1
			char peticion [128];
			sprintf(peticion,"%d",0);
			write(cliente->getDescriptor(),peticion,128);
			//---------------
			char fnamev [100];
			cout<< "Ingrese el archivo que va a enviar"<< endl;
			cin >> fnamev;
			cout<<"nombre de archivo: "<<fnamev<<endl;
			write(cliente->getDescriptor(),fnamev, 256);
			int sizek = -1;
			FILE *fpv = fopen(fnamev,"rb");
			int fdnm = fileno(fpv);
			fseek(fpv,0L, SEEK_END);
			sizek = ftell(fpv);
			rewind(fpv);
			char sizeCharx [256];
			sprintf(sizeCharx,"%d",sizek);
			cout<<sizeCharx<<endl;
			write(cliente->getDescriptor(),sizeCharx, sizeof(sizeCharx));
			if(fpv == NULL){
				printf("Error abriendo archivo");
			}else{
				
				while(1)
				{
					/* First read file in chunks of 256 bytes */
					unsigned char buffon[256]={0};
					int nreader = fread(buffon,1,256,fpv);
					cout << buffon<< endl;
					/* If read was success, send data. */
					if(nreader > 0)
					{
						printf("Sending \n");
						write(cliente->getDescriptor(), buffon, nreader);
					}
					if (nreader < 256)
					{
						if (feof(fpv))
						{
							printf("La transferencia ha terminado correctamente.\n");
							fclose(fpv);
						}
						if (ferror(fpv))
							printf("Error reading\n");
						break;
					}
				}
			}
			
		}
		else if(option == 1){
			//Solicitud para pedir lista ---- 1
			char peticion [128];
			sprintf(peticion,"%d",1);
			write(cliente->getDescriptor(),peticion,128);
			//------------------
			char tamMaquinasChar [128];
			read(cliente->getDescriptor(), tamMaquinasChar, 128);
			int tamMaquinas = atoi(tamMaquinasChar);
			cout <<"Seleccione la maquina:";
			for(int i =0; i < tamMaquinas; i++){
				cout << " "<< i;
			}
			cout<<endl;
			int maqSelec;
			cin >> maqSelec;
			char maqSelecChar [128];
			sprintf(maqSelecChar, "%d", maqSelec);
			write(cliente->getDescriptor(),maqSelecChar,128);
			
			
			// leyendo de servidor lista de archivos de maquina seleccionada
			char sizeListChar[128];
			read(cliente->getDescriptor(), sizeListChar, 128);
			int sizeList = atoi(sizeListChar);
			cout << "Lista de archivos:"<<endl;
			cout << "Tamanio: "<< sizeList<<endl;
			for (int i = 0; i < sizeList; ++i) {
				char contList[256];
				read(cliente->getDescriptor(), contList, 256);
				cout<<contList<<endl;
			}
		}else if(option == 2){
			char peticion [128];
			sprintf(peticion,"%d",2);
			write(cliente->getDescriptor(),peticion,128);
			char peticionElimin [128];
			cout <<"Escriba el nombre del archivo a eliminar:";
			cin>>peticionElimin;
			write(cliente->getDescriptor(),peticionElimin,128);
			cout << "El archivo se elimino correctamente" << endl;
			char balan[256];
			read(cliente->getDescriptor(), balan, 256);	
			cout<<balan<<endl;
		}else{
			cout<< "Opcion ingresada no es valida" << endl;
		}
	}
	
}

void Cliente::conectarServidor(){
	
	descriptorCliente= socket(AF_INET,SOCK_STREAM,0);
	servidorInfo.sin_family=AF_INET;
	
	inet_pton(AF_INET,ipServidor.c_str(),&servidorInfo.sin_addr);
	
	servidorInfo.sin_port=htons(puertoServidor);
	
	int conn=connect(descriptorCliente,(struct sockaddr *)&servidorInfo,sizeof(servidorInfo));
	
	if(conn!=-1){
		
		confirmacionAlmacenamiento(this);
		if(this->getAlmacenamiento()){
			pthread_t hiloRecibeArchivoMaquina;
			pthread_create(&hiloRecibeArchivoMaquina,NULL,atenderPetAlma,(void *)this);
		}
		else{
			pthread_t hiloEnviarArchivo;
			pthread_create(&hiloEnviarArchivo,NULL,menuCliente,(void *)this);
		}
		
		while(1);
	}else{
		
		cout<<"No se pudo conectar con el servidor"<<endl;
	}
}


int Cliente::getDescriptor(){
	return this->descriptorCliente;
}

void Cliente::setDescriptor(int descriptor){
	this->descriptorCliente=descriptor;
}

bool Cliente::getAlmacenamiento(){
	return this->esAlmacenamiento;
}

void Cliente::setAlmacenamiento(bool almacenamiento){
	this->esAlmacenamiento = almacenamiento;
}


